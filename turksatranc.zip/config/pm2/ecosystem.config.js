module.exports = {
    apps: [{
      name: 'turksatranc',
      script: 'server/server.js',
      cwd: '/Projeler/turksatranc',
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '1G',
      env: {
        NODE_ENV: 'production',
        PORT: 5010
      },
      env_development: {
        NODE_ENV: 'development',
        PORT: 5010
      }
    }]
  };